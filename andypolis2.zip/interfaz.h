#ifndef INTERFAZ_H
#define INTERFAZ_H

#include <iostream>

using namespace std;


class Interfaz {
    public:
    void menu();
    void pausa();
    void limpiar();
    void dormir(unsigned int tiempo);
};

#endif