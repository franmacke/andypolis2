#include <inventario.h>


Material * Inventario::obtener_materiales() {
    return lista_materiales;
}

Material Inventario::madera() {

}

Material Inventario::piedra() {
    
}

Material Inventario::metal() {
    
}